﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestConsoleApp;

namespace TestConsoleApp
{
    // Debugging practices.
    // Tasks: All these functions have some kind of error in their logic. Please identify the errors and solve them.
    // Note: The solution should not change the behavior of the function and do not change the parameters of the function.

    internal class Program
    {
        static void Main(string[] args)
        {
            Test1();
            Test2();
            Test3();
            Test4();
            Test5();
            AddNumbers(101.01d, 11, 3.75f, 3.142m);
        }

        private static void Test1()
        {
            var queryResult = new int?[] { 1, 2, null, 4 };
            var map = queryResult.Select(integer => (int)integer);

            // Display list.
            foreach (var num in map)
                Console.Write("{0} ", num);
            Console.WriteLine();
        }

        private static void Test2()
        {
            int[,] numbers = new int[,]
            {
                {0, 1 },
                {1, 12 },
                {2, 13 }
            };

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.WriteLine($"Position[{i},{j}]: {numbers[i, j]}");
                }
            }
        }

        private static void Test3()
        {
            List<Employee> employees = new List<Employee>()
            {
                new Employee(){ FirstName = "Michael", LastName = "Jordan" },
                new Employee(){ FirstName = "Lebron", LastName = "James" },
                new Employee(){ FirstName = "Bing", LastName = "Ah" }
            };

            Employee matchingResult = employees
                .Find(employee =>
                    employee.FirstName.Equals("Kai Rui", StringComparison.OrdinalIgnoreCase) 
                        && employee.LastName.Equals("Low", StringComparison.OrdinalIgnoreCase)
                        );

            Console.WriteLine($"Found employee {matchingResult.FirstName} {matchingResult.LastName}");
        }

        private static void Test4()
        {
            List<Employee> employees = new List<Employee>()
            {
                new Employee(){ FirstName = "Michael", LastName = "Jordan", BirthDate = new DateTime(1950, 3, 21) },
                new Employee(){ FirstName = "Lebron", LastName = "James", BirthDate = new DateTime(1980, 5, 15) },
                new Employee(){ FirstName = "Bing", LastName = "Ah" }
            };

            List<Employee> matchingResult = employees
                .Where(employee => employee.Age > 50)
                .ToList();

            Console.WriteLine("Employee who is at least 50 years old:");
            foreach (Employee employee in matchingResult)
            {
                Console.WriteLine($"{employee.FirstName} {employee.LastName}");
            }
        }

        private static void Test5()
        {
            List<Employee> employees = new List<Employee>()
            {
                new Employee(){ FirstName = "Michael", LastName = "Jordan", BirthDate = new DateTime(1950, 3, 21) },
                new Employee(){ FirstName = "Lebron", LastName = "James", BirthDate = new DateTime(1980, 5, 15) },
                new Employee(){ FirstName = "Bing", LastName = "Ah" },
                new Employee(){ FirstName = "Kai Rui", LastName = "Low"},
                new Employee(){ FirstName = "Barrack", LastName = "Obama"},
                new Employee(){ FirstName = "Lebron", LastName ="James", BirthDate = new DateTime(1994, 12, 1) }
            };

            Dictionary<string, Employee> employeeDictionary = new Dictionary<string, Employee>();
            
            foreach(Employee employee in employees)
            {
                employeeDictionary.Add($"{employee.FirstName} {employee.LastName}", employee);
            }

            foreach (string key in employeeDictionary.Keys)
            {
                Console.WriteLine($"Unique ID: {key}, Employee Name:{employeeDictionary[key].FirstName} {employeeDictionary[key].LastName}");
            }
        }

        private static void AddNumbers(params object[] numbers)
        {
            double result = double.NaN;
            for (int i = 0; i < numbers.Length; ++i)
            {
                result += (double)numbers[i];
                Console.Write(i == 0 ? $"{numbers[i]}" : i < numbers.Length - 1 ? $" + {numbers[i]}" : $" + {numbers[i]} \r\n");
            }

            Console.WriteLine($"Total: {result}");
        }
    }

    public class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime HireDate { get; set; }
        public DateTime? BirthDate { get; set; }
        public int Age
        {
            get
            {
                return (DateTime.Today.Year - BirthDate.Value.Year);
            }
        }
    }
}
